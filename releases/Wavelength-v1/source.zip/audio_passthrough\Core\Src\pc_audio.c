#include "main.h"
#include "pc_audio.h"
#ifdef AUDIO_PC_STREAM
#define PACKET_SAMPLES 64U
#define PACKET_SIZE (16U + PACKET_SAMPLES * 2U + 2U)
#define QUEUE_SIZE 8U
static uint8_t packets[QUEUE_SIZE][PACKET_SIZE];
static volatile uint32_t produced, consumed;
static uint32_t sequence;
volatile uint32_t g_pc_audio_dropped;
volatile uint32_t g_pc_audio_uart_errors;

static void put16(uint8_t *p, uint16_t value)
{
    p[0] = (uint8_t)value; p[1] = (uint8_t)(value >> 8);
}
static void put32(uint8_t *p, uint32_t value)
{
    put16(p, (uint16_t)value); put16(p + 2, (uint16_t)(value >> 16));
}
static uint16_t crc16(const uint8_t *p, uint32_t size)
{
    uint16_t crc = 0xffff;
    while (size--) {
        crc ^= (uint16_t)*p++ << 8;
        for (uint32_t bit = 0; bit < 8; ++bit) {
            crc = (uint16_t)((crc << 1) ^ ((crc & 0x8000U) ? 0x1021U : 0U));
        }
    }
    return crc;
}

void PC_Audio_Queue(const int16_t *samples)
{
    uint32_t seq = sequence++;
    if (produced - consumed >= QUEUE_SIZE) { ++g_pc_audio_dropped; return; }
    uint8_t *p = packets[produced % QUEUE_SIZE];
    p[0] = 'M'; p[1] = 'I'; p[2] = 'C'; p[3] = '1';
    put32(p + 4, seq);
    put32(p + 8, 16000U);
    put16(p + 12, PACKET_SAMPLES);
    put16(p + 14, g_pc_audio_dropped ? 1U : 0U);
    for (uint32_t i = 0; i < PACKET_SAMPLES; ++i) {
        put16(p + 16 + i * 2U, (uint16_t)samples[i]);
    }
    put16(p + PACKET_SIZE - 2U, crc16(p, PACKET_SIZE - 2U));
    __DMB();
    ++produced;
}

void PC_Audio_Poll(void)
{
    if (consumed == produced) { return; }
    __DMB();
    /* Foreground only; 146 bytes take about 1.6 ms at 921600 baud.
     * I2S DMA callbacks preempt this transfer and never call UART routines. */
    if (HAL_UART_Transmit(&huart2, packets[consumed % QUEUE_SIZE], PACKET_SIZE, 10) != HAL_OK) {
        ++g_pc_audio_uart_errors;
    }
    __DMB();
    ++consumed;
}
#endif
